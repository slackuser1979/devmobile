var express = require('express');
var app = express();
var mysqlConfig = require('./database/mysql-config');

app.set('port', (process.env.PORT || 3000));
app.use(express.static(__dirname + '/public'));

app.get('/paises', function(request, response) {
  console.log('Listagem');
  response.send([ {name: 'Brasil'}, {name: 'Argentina'}, {name: 'Estados Unidos'}, {name: 'Portugal'} ]);
  // try {
  //   mysqlConfig.connection.connect(err => {
  //     if (err) throw err;
  //     con.query('SELECT * FROM TABELA', function (err, result) {
  //       if (err) throw err;
  //       response.send(result);
  //     });
  //   });
  // } catch (err) {
  //   response.status(501).send(err);
  // }
});

app.post('/', function(request, response) {
  response.send('Inserir dados');
});

app.put('/', function(request, response) {
  response.send('Atualizar dados');
});

app.delete('/', function(request, response) {
  response.send('Remover dados');
});

app.listen(app.get('port'), function() {
  console.log("Aplicação rodando em localhost:" + app.get('port'));
});
